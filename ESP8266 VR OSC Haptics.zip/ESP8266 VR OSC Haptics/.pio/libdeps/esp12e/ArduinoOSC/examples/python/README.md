# how to use

Please install pip modules first.

```
$ pip install osc4py3 -t .
```

